package com.example.a2018070828


import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.IBinder
import android.view.View
import android.widget.SeekBar
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.activity_main.*
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity(), ServiceConnection {

    var binder : MusicService.MusicBinder ?=null
    var flag = false

    override fun onServiceDisconnected(name: ComponentName?) {
        binder = null
    }

    override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
        binder = service as MusicService.MusicBinder
        thread{
            while(binder != null){
                Thread.sleep(200)
                runOnUiThread{
                    if(binder!!.getisPrepared()){
                        seekBar.max = binder!!.getduration()
                        seekBar.progress = binder!!.getcurrentPosition()

                    }
                }
            }
        }
        thread{
            while(binder!= null){
                Thread.sleep(100)
                if(flag != binder!!.getflag()){
                    runOnUiThread {
                        music_textView.text = binder!!.getmusic()
                        singer_textView.text = binder!!.getsinger()
                        Glide.with(this).load(binder!!.getpicurl()).into(music_imageView)
                        flag = !flag
                    }
                }

            }
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        startMusicService()

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if(fromUser){
                    binder?.setcurrentPosition(progress)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar){}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })




    }

    fun startMusicService(){
        val intent = Intent(this,MusicService::class.java)
        startService(intent)
        bindService(intent,this,Context.BIND_AUTO_CREATE)

    }

    fun onrequest(v:View){
        val intent = Intent(this,MusicService::class.java)
        intent.putExtra(MusicService.commond,1)
        startService(intent)
        binder!!.setsort(spinner.selectedItem.toString())
    }


    fun onplay(v: View){
        val intent = Intent(this,MusicService::class.java)
        intent.putExtra(MusicService.commond,2)
        startService(intent)
    }

    fun onpause(v: View){
        val intent = Intent(this,MusicService::class.java)
        intent.putExtra(MusicService.commond,3)
        startService(intent)
    }

    fun onrestart(v: View){
        val intent = Intent(this,MusicService::class.java)
        intent.putExtra(MusicService.commond,4)
        startService(intent)
    }

    fun onstop(v: View){
        val intent = Intent(this,MusicService::class.java)
        intent.putExtra(MusicService.commond,5)
        startService(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        val intent = Intent(this,MusicService::class.java)
        stopService(intent)
        unbindService(this)
    }

}
