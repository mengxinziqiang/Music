package com.example.a2018070828

data class Data (
    val name: String,
    val url: String,
    val picurl: String,
    val artistsname: String
)
