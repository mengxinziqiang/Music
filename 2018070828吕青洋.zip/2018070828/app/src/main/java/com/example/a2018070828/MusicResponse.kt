package com.example.a2018070828

data class MusicResponse (
    val code : Int,
    val data : Data
)