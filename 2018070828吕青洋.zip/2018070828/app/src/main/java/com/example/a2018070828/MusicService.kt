package com.example.a2018070828

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.os.Binder
import android.os.IBinder
import android.util.Log
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class MusicService : Service() {

    companion object{
        val commond = "operator"
    }


    val Channel_ID = "music channel"
    val Notification_ID = 1
    val baseURL = "https://api.uomg.com/api/rand.music"
    val mediaPlayer = MediaPlayer()
    var url = ""
    var music = ""
    var singer = ""
    var picurl = ""
    var isPause = false
    var isPrepared = false
    val binder = MusicBinder()
    var sort = ""
    var flag = false

    inner class MusicBinder:Binder(){
        fun getmusic() = music
        fun getsinger() = singer
        fun getduration() = mediaPlayer.duration
        fun getcurrentPosition() = mediaPlayer.currentPosition
        fun setcurrentPosition(value: Int) = mediaPlayer.seekTo(value)
        fun getisPrepared() = isPrepared
        fun setsort(str:String){
            sort = str
        }
        fun getpicurl() = picurl
        fun getflag() = flag
    }

    override fun onCreate() {
        super.onCreate()

        //mediaplayer 准备好后回调
        mediaPlayer.setOnPreparedListener {
            isPrepared = true
            mediaPlayer.start()
            Log.d("main","prepared")
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {

        val operator = intent?.getIntExtra(commond,0) ?: 0
        when (operator){
            1 -> request()
            2 -> play()
            3 -> pause()
            4 -> restart()
            5 -> stop()
        }

        return super.onStartCommand(intent, flags, startId)
    }

    fun notification(){
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val builder: Notification.Builder
        val notificationChannel = NotificationChannel(Channel_ID,"music", NotificationManager.IMPORTANCE_LOW)
        notificationManager.createNotificationChannel(notificationChannel)
        builder = Notification.Builder(this,Channel_ID)

        val intent = Intent(this,MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(this,1,intent, PendingIntent.FLAG_UPDATE_CURRENT)

        val notification = builder.setSmallIcon(R.drawable.ic_notification_music)
            .setContentTitle("Music")
            .setContentText(music)
            .setContentIntent(pendingIntent)
            .build()

        notificationManager.notify(Notification_ID,notification)
    }

    fun request(){
        stop()
        isPause = false
        val queue = Volley.newRequestQueue(this)
        val stringRequest = StringRequest(baseURL+"?sort=${sort}&format=json",{
            val gson = Gson()
            val musicResponseType = object : TypeToken<MusicResponse>() {}.type
            val musicResponse = gson.fromJson<MusicResponse>(it,musicResponseType)
            Log.d("service",it)
            music = musicResponse.data.name
            singer = musicResponse.data.artistsname
            url = musicResponse.data.url
            picurl = musicResponse.data.picurl
            flag = !flag
            Log.d("Main",musicResponse.data.name)
        },{
            Log.d("Main","$it")
        })
        queue.add(stringRequest)
    }

    fun play(){
        if(isPrepared){
            if(isPause){
                isPause = false
            }
            mediaPlayer.start()
        }else{
            if(url=="")return
            mediaPlayer.reset()
            mediaPlayer.setDataSource(url)
            mediaPlayer.prepareAsync()
            notification()
        }
    }

    fun pause(){
        if(isPrepared){
            if(isPause){
                mediaPlayer.start()
                isPause = false
            }
            else{
                mediaPlayer.pause()
                isPause = true
            }
        }
    }

    fun stop(){
        if(isPrepared){
            mediaPlayer.seekTo(0)
            mediaPlayer.stop()
            isPrepared = false
        }
    }

    fun restart(){
        if(isPrepared){
            mediaPlayer.seekTo(0)
        }
    }



    override fun onBind(intent: Intent): IBinder {
        return binder
    }
}
